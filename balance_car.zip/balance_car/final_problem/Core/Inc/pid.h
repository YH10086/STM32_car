#ifndef __PID_H
#define __PID_H
extern int speed1,speed2;
extern float roll;
extern short gyroz;
extern int target_speed;
extern int error_Sum,error_LowOut_Last;
void car_control();
#endif