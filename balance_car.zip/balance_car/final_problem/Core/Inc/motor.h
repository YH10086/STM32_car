#ifndef __MOTOR_H
#define __MOTOR_H
void ChangeSpeed(int motor1,int motor2);
void Limit_Speed(int* speed1,int* speed2);
#endif