#ifndef __ENCODER_H
#define __ENCODER_H
#include "tim.h"
int GetSpeed(TIM_HandleTypeDef htim);
#endif