#ifndef __SR04_H
#define __SR04_H
extern float distance;
extern uint16_t counter;
void SR04_SendTrig();


#endif