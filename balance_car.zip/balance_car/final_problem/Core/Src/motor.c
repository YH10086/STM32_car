#include "stm32f1xx_hal.h"
#include"tim.h"
#define speed_max 7200
#define nege_speed_max -7200 //�������
int abs(int x){
if(x) return x;
else return -x;
}
void ChangeSpeed(int motor1,int motor2){  //��ֵ�͸�pwm���ı�ռ�ձȣ�ȷ���������
if(motor1<0){
HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12,GPIO_PIN_SET);
HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13,GPIO_PIN_RESET);	
}
else{
HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13,GPIO_PIN_SET);
HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12,GPIO_PIN_RESET);	
}
__HAL_TIM_SetCompare(&htim1,TIM_CHANNEL_1,abs(motor1));

if(motor2<0){
HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15,GPIO_PIN_SET);
HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14,GPIO_PIN_RESET);	
}
else{
HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14,GPIO_PIN_SET);
HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15,GPIO_PIN_RESET);	
}
__HAL_TIM_SetCompare(&htim1,TIM_CHANNEL_4,abs(motor2));
}

void Limit_Speed(int* speed1,int* speed2){ //�������
if(*speed1>speed_max) *speed1=speed_max;
else if(*speed1<nege_speed_max) *speed1=nege_speed_max;
	
if(*speed2>speed_max) *speed2=speed_max;
else if(*speed2<nege_speed_max) *speed2=nege_speed_max;
}