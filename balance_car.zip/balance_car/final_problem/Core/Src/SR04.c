#include"stm32f1xx_hal.h"
#include"tim.h"
#include"SR04.h"
#define SR04_Trig GPIO_PIN_3
#define SR04_Echo GPIO_PIN_2
#define SR04_Port GPIOA
uint16_t counter;
float distance;
void RCCdelay_us(uint32_t udelay)//��ѭ��ʵ��΢����ʱ
{
  __IO uint32_t Delay = udelay * 72 / 8;//(SystemCoreClock / 8U / 1000000U)
    //��stm32f1xx_hal_rcc.c -- static void RCC_Delay(uint32_t mdelay)
  do
  {
    __NOP();
  }
  while (Delay --);
}

void SR04_SendTrig(){//���ʹ����ź�
HAL_GPIO_WritePin(SR04_Port,SR04_Trig,GPIO_PIN_SET);
RCCdelay_us(13);
HAL_GPIO_WritePin(SR04_Port,SR04_Trig,GPIO_PIN_RESET);
}




